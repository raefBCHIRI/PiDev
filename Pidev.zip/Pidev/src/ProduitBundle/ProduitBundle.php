<?php

namespace ProduitBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProduitBundle extends Bundle
{
}
